export type Category = "jackets" | "hoodies" | "pants" | "tees"

export type Product = {
  slug: string
  name: string
  nameEn: string
  category: Category
  price: number
  image: string
  color: string
  fabric: string
  description: string
  featured?: boolean
}

export const CATEGORIES: { id: Category | "all"; label: string; labelEn: string }[] = [
  { id: "all", label: "الكل", labelEn: "ALL" },
  { id: "jackets", label: "جواكت", labelEn: "JACKETS" },
  { id: "hoodies", label: "هوديز وسويت شيرت", labelEn: "HOODIES" },
  { id: "pants", label: "بناطيل", labelEn: "PANTS" },
  { id: "tees", label: "تيشرتات وبادي", labelEn: "TEES" },
]

export const TOP_SIZES = ["S", "M", "L", "XL", "XXL"] as const
export const PANT_SIZES = ["30", "32", "34", "36", "38"] as const

export const PRODUCTS: Product[] = [
  {
    slug: "tete-puffer-jacket",
    name: "جاكيت بافر TETE",
    nameEn: "PUFFER JACKET",
    category: "jackets",
    price: 3200,
    image: "/images/puffer-jacket.webp",
    color: "أسود مطفي",
    fabric: "نايلون Ripstop مقاوم للمياه وحشو حراري خفيف",
    description:
      "جاكيت بافر بقصّة Boxy وحشو حراري يحافظ على الدفء بدون وزن زيادة. ياقة عالية وسوستة معدنية ثقيلة.",
    featured: true,
  },
  {
    slug: "varsity-jacket",
    name: "جاكيت فارسيتي",
    nameEn: "VARSITY JACKET",
    category: "jackets",
    price: 2450,
    image: "/images/varsity-jacket.webp",
    color: "أسود / كريمي",
    fabric: "صوف مخلوط مع أكمام جلد صناعي",
    description:
      "كلاسيكية الـ Varsity بلمسة شارع حديثة. أزرار كبس معدنية وحواف مضلعة بخطوط متباينة.",
    featured: true,
  },
  {
    slug: "denim-trucker-jacket",
    name: "جاكيت جينز تراكر",
    nameEn: "DENIM TRUCKER",
    category: "jackets",
    price: 1650,
    image: "/images/denim-jacket.webp",
    color: "أسود مغسول",
    fabric: "دنيم قطن 100% وزن 14 أونصة",
    description:
      "جاكيت تراكر بغسلة سوداء باهتة وقصّة واسعة قليلاً. جيوب صدر بغطاء وأزرار نحاسية.",
    featured: true,
  },
  {
    slug: "signature-zip-jacket",
    name: "جاكيت TETE سيجنتشر",
    nameEn: "SIGNATURE ZIP JACKET",
    category: "jackets",
    price: 2200,
    image: "/images/signature-zip-jacket.webp",
    color: "أسود فحمي",
    fabric: "قطن فليس ثقيل 450 GSM مع بطانة ناعمة",
    description:
      "القطعة الأيقونية للبراند: سوستة معدنية ثقيلة، حبال بأطراف معدنية، وشعار TETE مطرّز بكثافة عالية.",
  },
  {
    slug: "technical-windbreaker",
    name: "جاكيت ويندبريكر",
    nameEn: "WINDBREAKER",
    category: "jackets",
    price: 1200,
    image: "/images/windbreaker.webp",
    color: "رمادي فحمي",
    fabric: "بوليستر تقني خفيف مقاوم للرياح",
    description: "طبقة خفيفة للأيام المتقلبة. كابيشون مخفي وأساور قابلة للضبط.",
  },
  {
    slug: "oversized-heavy-hoodie",
    name: "هودي أوفرسايز ثقيل",
    nameEn: "HEAVY HOODIE",
    category: "hoodies",
    price: 1150,
    image: "/images/heavy-hoodie.webp",
    color: "رمادي مغسول",
    fabric: "قطن فليس 420 GSM",
    description: "هودي بقصّة أوفرسايز وأكتاف منخفضة وغسلة باهتة تعطي إحساس القطعة القديمة المحبوبة.",
  },
  {
    slug: "zip-up-hoodie",
    name: "هودي بسوستة",
    nameEn: "ZIP HOODIE",
    category: "hoodies",
    price: 1050,
    image: "/images/zip-hoodie.webp",
    color: "زيتي",
    fabric: "قطن فليس 380 GSM",
    description: "هودي بسوستة كاملة بقصّة Relaxed، مثالي كطبقة فوق التيشرت.",
  },
  {
    slug: "crewneck-sweatshirt",
    name: "سويت شيرت كرو",
    nameEn: "CREWNECK",
    category: "hoodies",
    price: 850,
    image: "/images/crewneck.webp",
    color: "أوف وايت",
    fabric: "قطن تيري 350 GSM",
    description: "سويت شيرت بقصّة Boxy وأساور مضلعة. بساطة نظيفة تتنسق مع كل شيء.",
  },
  {
    slug: "baggy-wide-jeans",
    name: "جينز باجي واسع",
    nameEn: "BAGGY JEANS",
    category: "pants",
    price: 1100,
    image: "/images/baggy-jeans.webp",
    color: "أزرق متوسط باهت",
    fabric: "دنيم قطن 100% وزن 13 أونصة",
    description: "جينز بساق واسعة وخصر مريح بغسلة زرقاء باهتة. القطعة الأساسية لأي لوك ستريت.",
  },
  {
    slug: "beige-cargo-pants",
    name: "بنطلون كارجو بيج",
    nameEn: "CARGO PANTS",
    category: "pants",
    price: 950,
    image: "/images/beige-cargo.webp",
    color: "بيج",
    fabric: "تويل قطن متين",
    description: "كارجو بجيوب جانبية واسعة وقصّة مستقيمة مريحة، بلون بيج سهل التنسيق.",
  },
  {
    slug: "boxy-heavy-tee",
    name: "تيشرت بوكسي",
    nameEn: "BOXY TEE",
    category: "tees",
    price: 650,
    image: "/images/boxy-tee.webp",
    color: "أبيض",
    fabric: "قطن جيرسيه 260 GSM",
    description: "تيشرت ثقيل بقصّة مربعة وياقة سميكة لا تفقد شكلها بعد الغسيل.",
  },
  {
    slug: "tete-graphic-tee",
    name: "تيشرت جرافيك TETE",
    nameEn: "GRAPHIC TEE",
    category: "tees",
    price: 800,
    image: "/images/graphic-tee.webp",
    color: "أسود",
    fabric: "قطن جيرسيه 240 GSM بطباعة Puff",
    description: "تيشرت أوفرسايز بطباعة جرافيك بارزة على الصدر بتأثير Distressed.",
  },
  {
    slug: "ribbed-body",
    name: "بادي ريب",
    nameEn: "RIBBED BODY",
    category: "tees",
    price: 480,
    image: "/images/ribbed-body.webp",
    color: "أسود",
    fabric: "قطن ريب مطاطي",
    description: "بادي ريب بقصّة ضيقة، طبقة أساسية تحت الجواكت والقمصان المفتوحة.",
  },
]

export const STORY_PRODUCT_SLUG = "signature-zip-jacket"

export function getProduct(slug: string) {
  return PRODUCTS.find((p) => p.slug === slug)
}

export function getFeaturedProducts() {
  return PRODUCTS.filter((p) => p.featured)
}

export function getSizes(category: Category): readonly string[] {
  return category === "pants" ? PANT_SIZES : TOP_SIZES
}

export function getDefaultSize(category: Category) {
  return category === "pants" ? "32" : "M"
}

export function getCategoryLabel(category: Category) {
  return CATEGORIES.find((c) => c.id === category)?.label ?? ""
}

const LOOK_PAIRINGS: Record<Category, Category[]> = {
  jackets: ["tees", "pants"],
  hoodies: ["pants", "tees"],
  pants: ["hoodies", "tees"],
  tees: ["jackets", "pants"],
}

export function getCompleteTheLook(product: Product): Product[] {
  const seed = product.slug.length
  return LOOK_PAIRINGS[product.category]
    .map((category) => {
      const options = PRODUCTS.filter((p) => p.category === category && p.slug !== product.slug)
      return options[seed % options.length]
    })
    .filter(Boolean)
}

export function formatEGP(value: number) {
  return `${value.toLocaleString("en-US")} ج.م`
}
