"use client"

import Link from "next/link"
import { ShoppingBag } from "lucide-react"
import { useCart } from "@/components/cart/cart-provider"

const NAV = [
  { href: "/#story", label: "القصة" },
  { href: "/#shop", label: "المتجر" },
  { href: "/#featured", label: "الجواكت" },
]

export function SiteHeader() {
  const { count, setOpen, bumpKey } = useCart()

  return (
    <header className="sticky top-0 z-40 border-b border-border/60 bg-background/75 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-6 px-4 md:px-8">
        <Link href="/" className="font-display text-2xl uppercase tracking-wide" aria-label="TETE STORE - الرئيسية">
          TETE<span className="text-primary">.</span>STORE
        </Link>

        <nav aria-label="التنقل الرئيسي" className="hidden md:block">
          <ul className="flex items-center gap-8 text-sm text-muted-foreground">
            {NAV.map((item) => (
              <li key={item.href}>
                <Link href={item.href} className="transition-colors hover:text-foreground">
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <button
          id="cart-button"
          type="button"
          onClick={() => setOpen(true)}
          className="relative flex items-center gap-2 rounded-full border border-border bg-card px-4 py-2 text-sm transition-colors hover:border-primary/60 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
          aria-label={`فتح السلة، ${count} قطعة`}
        >
          <ShoppingBag className="size-4" aria-hidden="true" />
          <span className="hidden sm:inline">السلة</span>
          <span
            key={bumpKey}
            className="flex size-5 items-center justify-center rounded-full bg-primary text-xs font-semibold text-primary-foreground tabular-nums animate-cart-bump motion-reduce:animate-none"
          >
            {count}
          </span>
        </button>
      </div>
    </header>
  )
}
