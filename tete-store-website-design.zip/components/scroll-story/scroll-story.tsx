"use client"

import Link from "next/link"
import { useEffect, useRef, useState } from "react"
import { ArrowLeft } from "lucide-react"
import { cn } from "@/lib/utils"
import { formatEGP, getProduct, STORY_PRODUCT_SLUG } from "@/lib/products"
import { StoryVisual } from "@/components/scroll-story/story-visual"

const STAGES = [
  {
    en: "01 — FABRIC",
    title: "نسيج تحسّه قبل ما تلبسه",
    lines: [
      "قطن فليس ثقيل 450 GSM مغزول من ألياف طويلة التيلة.",
      "بطانة داخلية مصقولة، ناعمة على الجلد ودافية من غير تقل.",
      "ثبات في اللون والشكل بعد عشرات الغسلات.",
    ],
  },
  {
    en: "02 — DETAILS & HARDWARE",
    title: "التفاصيل اللي بتفرق",
    lines: [
      "سوستة معدنية ثقيلة بتشطيب مطفي وحركة ناعمة.",
      "حبال قطنية مضفرة بأطراف معدنية محفورة.",
      "شعار TETE STORE مطرّز بكثافة عالية تعيش للأبد.",
    ],
  },
  {
    en: "03 — ASSEMBLY",
    title: "كل قطعة في مكانها",
    lines: [
      "باترون من 6 أجزاء بقصّة Boxy مدروسة بالملّي.",
      "خياطة مزدوجة على الأكتاف والجوانب لتحمّل أطول.",
      "تجميع وتشطيب يدوي لكل حافة قبل الفحص النهائي.",
    ],
  },
  {
    en: "04 — FULL SILHOUETTE",
    title: "النتيجة: Signature Zip Jacket",
    lines: [
      "حرّك الماوس على القطعة… هي بتتفاعل معاك.",
      "أكتاف منخفضة وطول مثالي فوق الجينز الواسع.",
      "متاحة الآن بكميات محدودة من الـ Drop ده.",
    ],
  },
] as const

const clamp = (v: number, min = 0, max = 1) => Math.min(max, Math.max(min, v))

export function ScrollStory() {
  const sectionRef = useRef<HTMLElement>(null)
  const [progress, setProgress] = useState(0)
  const product = getProduct(STORY_PRODUCT_SLUG)!

  useEffect(() => {
    let frame = 0
    const update = () => {
      frame = 0
      const el = sectionRef.current
      if (!el) return
      const rect = el.getBoundingClientRect()
      const scrollable = rect.height - window.innerHeight
      setProgress(clamp(-rect.top / scrollable))
    }
    const onScroll = () => {
      if (!frame) frame = requestAnimationFrame(update)
    }
    update()
    window.addEventListener("scroll", onScroll, { passive: true })
    window.addEventListener("resize", onScroll)
    return () => {
      cancelAnimationFrame(frame)
      window.removeEventListener("scroll", onScroll)
      window.removeEventListener("resize", onScroll)
    }
  }, [])

  const stageIndex = Math.min(3, Math.floor(progress * 4))
  const localT = clamp(progress * 4 - stageIndex)
  const stage = STAGES[stageIndex]

  return (
    <section
      id="story"
      ref={sectionRef}
      className="relative h-[520vh] scroll-mt-16"
      aria-label="قصة صناعة القطعة"
    >
      <div className="sticky top-16 flex h-[calc(100svh-4rem)] items-center overflow-hidden">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 bg-[radial-gradient(50%_45%_at_30%_50%,oklch(0.72_0.19_45/0.08),transparent)]"
        />
        <div className="relative mx-auto grid w-full max-w-7xl items-center gap-6 px-4 md:px-8 lg:grid-cols-2 lg:gap-16">
          <div className="order-2 flex flex-col gap-5 lg:order-1">
            <ol className="flex gap-2" aria-label="مراحل القصة">
              {STAGES.map((s, i) => (
                <li key={s.en} className="flex flex-1 flex-col gap-2">
                  <div className="h-0.5 overflow-hidden rounded-full bg-muted">
                    <div className="h-full bg-primary" style={{ width: `${clamp(progress * 4 - i) * 100}%` }} />
                  </div>
                  <span
                    className={cn(
                      "hidden font-display text-[10px] tracking-widest uppercase transition-colors sm:block",
                      i === stageIndex ? "text-foreground" : "text-muted-foreground/60",
                    )}
                  >
                    {s.en.split(" — ")[1]}
                  </span>
                </li>
              ))}
            </ol>

            <div key={stageIndex} className="flex flex-col gap-4 animate-in fade-in slide-in-from-bottom-4 duration-700">
              <p className="font-display text-sm tracking-[0.3em] text-primary uppercase" dir="ltr">
                <span className="inline-block w-full text-end">{stage.en}</span>
              </p>
              <h2 className="text-balance text-3xl leading-tight font-bold md:text-5xl">{stage.title}</h2>
              <ul className="flex flex-col gap-3">
                {stage.lines.map((line, j) => {
                  const shown = localT >= 0.08 + j * 0.22 || (stageIndex === 0 && j === 0)
                  return (
                    <li
                      key={line}
                      className={cn(
                        "flex items-start gap-3 text-pretty text-base leading-relaxed transition-all duration-700 md:text-lg",
                        shown ? "translate-y-0 opacity-100" : "translate-y-3 opacity-0",
                      )}
                    >
                      <span className="mt-2.5 size-1.5 shrink-0 rounded-full bg-primary" aria-hidden="true" />
                      <span className="text-muted-foreground">{line}</span>
                    </li>
                  )
                })}
              </ul>
              {stageIndex === 3 && (
                <div
                  className={cn(
                    "flex flex-wrap items-center gap-4 pt-2 transition-all duration-700",
                    localT > 0.55 ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-3 opacity-0",
                  )}
                >
                  <Link
                    href={`/product/${product.slug}`}
                    className="group inline-flex h-12 items-center gap-3 rounded-full bg-primary px-7 font-semibold text-primary-foreground transition-transform hover:scale-105"
                  >
                    اطلبها الآن
                    <ArrowLeft className="size-4 transition-transform group-hover:-translate-x-1" aria-hidden="true" />
                  </Link>
                  <span className="text-lg tabular-nums">{formatEGP(product.price)}</span>
                </div>
              )}
            </div>
          </div>

          <div className="order-1 lg:order-2">
            <StoryVisual progress={progress} stageIndex={stageIndex} localT={localT} image={product.image} />
          </div>
        </div>

        <p className="absolute bottom-6 inset-x-0 text-center text-xs text-muted-foreground/70" aria-hidden="true">
          {progress < 0.02 ? "انزل لتكتشف كيف تُصنع القطعة" : `${Math.round(progress * 100)}%`}
        </p>
      </div>
    </section>
  )
}
