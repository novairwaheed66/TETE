"use client"

import Image from "next/image"
import { useRef } from "react"

const clamp = (v: number, min = 0, max = 1) => Math.min(max, Math.max(min, v))
const easeOutCubic = (t: number) => 1 - Math.pow(1 - t, 3)
const easeInOut = (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2)

function layerOpacity(i: number, p: number) {
  const start = i / 4
  const end = (i + 1) / 4
  const span = 0.05
  const fadeIn = i === 0 ? 1 : (p - (start - span / 2)) / span
  const fadeOut = i === 3 ? 1 : (end + span / 2 - p) / span
  return clamp(Math.min(fadeIn, fadeOut))
}

const DETAILS = [
  { src: "/images/detail-zipper.webp", label: "METAL ZIPPER", ar: "سوستة معدنية", className: "row-span-2" },
  { src: "/images/detail-drawstring.webp", label: "DRAWSTRINGS", ar: "حبال بأطراف معدنية", className: "" },
  { src: "/images/detail-embroidery.webp", label: "EMBROIDERY", ar: "تطريز الشعار", className: "" },
]

const TILES = [
  { x: -70, y: -45, r: -16 },
  { x: 75, y: -55, r: 14 },
  { x: -95, y: 5, r: -9 },
  { x: 90, y: 12, r: 11 },
  { x: -60, y: 60, r: -13 },
  { x: 70, y: 65, r: 15 },
]

export function StoryVisual({
  progress,
  stageIndex,
  localT,
  image,
}: {
  progress: number
  stageIndex: number
  localT: number
  image: string
}) {
  const tiltRef = useRef<HTMLDivElement>(null)

  const fabricT = stageIndex === 0 ? localT : stageIndex > 0 ? 1 : 0
  const detailsT = stageIndex === 1 ? localT : stageIndex > 1 ? 1 : 0
  const assemblyT = stageIndex === 2 ? localT : stageIndex > 2 ? 1 : 0
  const silhouetteT = stageIndex === 3 ? localT : 0

  const assembled = easeOutCubic(clamp(assemblyT / 0.8))
  const zoom = 0.86 + 0.24 * Math.sin(Math.PI * silhouetteT)

  function handlePointerMove(e: React.PointerEvent<HTMLDivElement>) {
    const el = tiltRef.current
    if (!el || e.pointerType === "touch") return
    const rect = el.getBoundingClientRect()
    const px = (e.clientX - rect.left) / rect.width
    const py = (e.clientY - rect.top) / rect.height
    el.style.setProperty("--ry", `${(px - 0.5) * 22}deg`)
    el.style.setProperty("--rx", `${(0.5 - py) * 18}deg`)
    el.style.setProperty("--gx", `${px * 100}%`)
    el.style.setProperty("--gy", `${py * 100}%`)
  }

  function handlePointerLeave() {
    const el = tiltRef.current
    if (!el) return
    el.style.setProperty("--ry", "0deg")
    el.style.setProperty("--rx", "0deg")
    el.style.setProperty("--gx", "50%")
    el.style.setProperty("--gy", "35%")
  }

  return (
    <div
      dir="ltr"
      className="relative mx-auto aspect-square w-full max-w-[min(420px,42svh)] sm:max-w-[min(520px,50svh)] lg:max-w-[min(580px,70svh)]"
    >
      {/* Stage 1 — fabric zoom */}
      <div
        className="absolute inset-0 overflow-hidden rounded-3xl border border-border"
        style={{ opacity: layerOpacity(0, progress) }}
        aria-hidden={stageIndex !== 0}
      >
        <Image
          src="/images/story-fabric.webp"
          alt="لقطة مقرّبة لنسيج القطن الفاخر والبطانة"
          fill
          sizes="(min-width: 1024px) 580px, 90vw"
          className="object-cover will-change-transform"
          style={{ transform: `scale(${1 + 0.85 * easeInOut(fabricT)}) rotate(${fabricT * 4}deg)` }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background/70 via-transparent to-transparent" />
        <div className="absolute bottom-5 left-5 flex flex-wrap gap-2">
          {["450 GSM", "100% COTTON", "BRUSHED LINING"].map((chip, i) => (
            <span
              key={chip}
              className="rounded-full border border-foreground/20 bg-background/60 px-3 py-1 font-display text-[11px] tracking-widest backdrop-blur transition-all duration-500"
              style={{ opacity: fabricT > 0.1 + i * 0.22 ? 1 : 0, transform: `translateY(${fabricT > 0.1 + i * 0.22 ? 0 : 8}px)` }}
            >
              {chip}
            </span>
          ))}
        </div>
      </div>

      {/* Stage 2 — hardware details */}
      <div
        className="absolute inset-0 grid grid-cols-2 grid-rows-2 gap-3"
        style={{ opacity: layerOpacity(1, progress) }}
        aria-hidden={stageIndex !== 1}
      >
        {DETAILS.map((d, i) => {
          const cp = easeOutCubic(clamp((detailsT - (0.05 + i * 0.22)) / 0.25))
          return (
            <figure
              key={d.src}
              className={`relative overflow-hidden rounded-2xl border border-border bg-studio ${d.className}`}
              style={{
                opacity: cp,
                transform: `translateY(${(1 - cp) * 40}px) scale(${0.9 + 0.1 * cp})`,
              }}
            >
              <Image
                src={d.src}
                alt={d.ar}
                fill
                sizes="(min-width: 1024px) 290px, 45vw"
                className="object-cover"
                style={{ transform: `scale(${1.15 - 0.15 * cp})` }}
              />
              <figcaption className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-2 bg-gradient-to-t from-background/90 to-transparent p-3 pt-10">
                <span className="font-display text-xs tracking-widest">{d.label}</span>
                <span dir="rtl" className="text-xs text-muted-foreground">{d.ar}</span>
              </figcaption>
            </figure>
          )
        })}
      </div>

      {/* Stage 3 — assembly of panels */}
      <div
        className="absolute inset-0 grid grid-cols-2 grid-rows-3"
        style={{ opacity: layerOpacity(2, progress) }}
        aria-hidden="true"
      >
        {TILES.map((tile, i) => {
          const col = i % 2
          const row = Math.floor(i / 2)
          const delay = i * 0.04
          const e = easeOutCubic(clamp((assemblyT - delay) / 0.75))
          return (
            <div
              key={i}
              className="relative will-change-transform"
              style={{
                backgroundImage: `url(${image})`,
                backgroundSize: "200% 300%",
                backgroundPosition: `${col * 100}% ${row * 50}%`,
                transform: `translate(${tile.x * (1 - e)}%, ${tile.y * (1 - e)}%) rotate(${tile.r * (1 - e)}deg) scale(${0.82 + 0.18 * e})`,
                opacity: 0.25 + 0.75 * e,
                borderRadius: `${(1 - assembled) * 14}px`,
                outline: `1px dashed oklch(0.72 0.19 45 / ${(1 - e) * 0.9})`,
                outlineOffset: "-1px",
              }}
            />
          )
        })}
        <div
          className="pointer-events-none absolute inset-0 rounded-3xl border border-border"
          style={{ opacity: assembled }}
        />
      </div>

      {/* Stage 4 — full silhouette with tilt & spotlight */}
      <div
        className="absolute inset-0"
        style={{ opacity: layerOpacity(3, progress), perspective: "1100px", pointerEvents: stageIndex === 3 ? "auto" : "none" }}
        onPointerMove={handlePointerMove}
        onPointerLeave={handlePointerLeave}
      >
        <div
          ref={tiltRef}
          className="relative size-full transition-transform duration-200 ease-out"
          style={{
            transform: `scale(${zoom}) rotateX(var(--rx, 0deg)) rotateY(var(--ry, 0deg))`,
            transformStyle: "preserve-3d",
          }}
        >
          <div
            aria-hidden="true"
            className="absolute -inset-10 rounded-full blur-3xl"
            style={{
              background: "radial-gradient(circle at var(--gx, 50%) var(--gy, 35%), oklch(0.72 0.19 45 / 0.35), transparent 55%)",
              transform: "translateZ(-60px)",
            }}
          />
          <div className="relative size-full animate-float motion-reduce:animate-none">
            <div className="relative size-full overflow-hidden rounded-3xl border border-border bg-studio shadow-[0_40px_80px_-30px_oklch(0_0_0/0.8)]">
              <Image
                src={image}
                alt="جاكيت TETE Signature بالكامل"
                fill
                sizes="(min-width: 1024px) 580px, 90vw"
                className="object-cover"
              />
              <div
                aria-hidden="true"
                className="pointer-events-none absolute inset-0 mix-blend-soft-light"
                style={{
                  background: "radial-gradient(380px circle at var(--gx, 50%) var(--gy, 35%), oklch(1 0 0 / 0.55), transparent 60%)",
                }}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
