"use client"

import { useState } from "react"
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group"
import { ProductCard } from "@/components/product-card"
import { CATEGORIES, PRODUCTS, type Category } from "@/lib/products"

export function ShopSection() {
  const [active, setActive] = useState<Category | "all">("all")
  const visible = active === "all" ? PRODUCTS : PRODUCTS.filter((p) => p.category === active)

  return (
    <section id="shop" className="scroll-mt-20" aria-labelledby="shop-title">
      <div className="mx-auto flex max-w-7xl flex-col gap-8 px-4 py-24 md:px-8">
        <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
          <div className="flex flex-col gap-2">
            <p className="font-display text-sm tracking-[0.3em] text-primary uppercase">THE SHOP</p>
            <h2 id="shop-title" className="text-balance text-4xl font-bold md:text-5xl">
              كل المجموعة
            </h2>
          </div>
          <ToggleGroup
            value={[active]}
            onValueChange={(value) => value[0] && setActive(value[0] as Category | "all")}
            variant="outline"
            spacing={2}
            className="flex-wrap"
            aria-label="تصفية حسب الفئة"
          >
            {CATEGORIES.map((c) => (
              <ToggleGroupItem key={c.id} value={c.id} className="rounded-full px-4">
                {c.label}
              </ToggleGroupItem>
            ))}
          </ToggleGroup>
        </div>

        <ul className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4" aria-live="polite">
          {visible.map((product, i) => (
            <li
              key={`${active}-${product.slug}`}
              className="animate-in fade-in zoom-in-95 fill-mode-both duration-500"
              style={{ animationDelay: `${i * 50}ms` }}
            >
              <ProductCard product={product} />
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
