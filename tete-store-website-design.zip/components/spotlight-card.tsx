"use client"

import { useRef } from "react"
import { cn } from "@/lib/utils"

export function SpotlightCard({
  className,
  children,
  intensity = 0.14,
}: {
  className?: string
  children: React.ReactNode
  intensity?: number
}) {
  const ref = useRef<HTMLDivElement>(null)

  function handlePointerMove(e: React.PointerEvent<HTMLDivElement>) {
    const el = ref.current
    if (!el) return
    const rect = el.getBoundingClientRect()
    el.style.setProperty("--spot-x", `${e.clientX - rect.left}px`)
    el.style.setProperty("--spot-y", `${e.clientY - rect.top}px`)
  }

  return (
    <div
      ref={ref}
      onPointerMove={handlePointerMove}
      className={cn("group/spot relative isolate overflow-hidden", className)}
      style={{ "--spot-intensity": intensity } as React.CSSProperties}
    >
      {children}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 z-10 opacity-0 transition-opacity duration-300 group-hover/spot:opacity-100"
        style={{
          background:
            "radial-gradient(420px circle at var(--spot-x, 50%) var(--spot-y, 50%), oklch(1 0 0 / var(--spot-intensity)), transparent 45%)",
        }}
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 z-10 rounded-[inherit] opacity-0 transition-opacity duration-300 group-hover/spot:opacity-100"
        style={{
          padding: "1px",
          background:
            "radial-gradient(260px circle at var(--spot-x, 50%) var(--spot-y, 50%), oklch(0.72 0.19 45 / 0.8), transparent 60%)",
          WebkitMask: "linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)",
          WebkitMaskComposite: "xor",
          maskComposite: "exclude",
        }}
      />
    </div>
  )
}
