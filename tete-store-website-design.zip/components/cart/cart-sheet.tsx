"use client"

import Image from "next/image"
import Link from "next/link"
import { useState } from "react"
import { Minus, Plus, ShoppingBag, Trash2 } from "lucide-react"
import { toast } from "sonner"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Empty, EmptyDescription, EmptyHeader, EmptyMedia, EmptyTitle } from "@/components/ui/empty"
import { Sheet, SheetContent, SheetDescription, SheetFooter, SheetHeader, SheetTitle } from "@/components/ui/sheet"
import { MAX_QTY_PER_LINE, useCart } from "@/components/cart/cart-provider"
import { formatEGP, getSizes } from "@/lib/products"

const FREE_SHIPPING_THRESHOLD = 3000
const SHIPPING_FEE = 75

export function CartSheet() {
  const { lines, count, subtotal, isOpen, setOpen, setQty, setSize, remove, clear } = useCart()
  const [checkingOut, setCheckingOut] = useState(false)

  const shipping = subtotal === 0 || subtotal >= FREE_SHIPPING_THRESHOLD ? 0 : SHIPPING_FEE
  const total = subtotal + shipping
  const remaining = Math.max(0, FREE_SHIPPING_THRESHOLD - subtotal)

  async function handleCheckout() {
    setCheckingOut(true)
    try {
      const res = await fetch("/api/cart/quote", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ lines: lines.map(({ slug, size, qty }) => ({ slug, size, qty })) }),
      })
      const data = await res.json()
      if (!res.ok) {
        toast.error(data.error ?? "تعذر التحقق من الطلب")
        return
      }
      toast.success(`تم تأكيد طلبك بإجمالي ${formatEGP(data.subtotal + shipping)}`, {
        description: "تم التحقق من الأسعار والكميات من الخادم.",
      })
      clear()
      setOpen(false)
    } catch {
      toast.error("حدث خطأ في الاتصال، حاول مرة أخرى")
    } finally {
      setCheckingOut(false)
    }
  }

  return (
    <Sheet open={isOpen} onOpenChange={setOpen}>
      <SheetContent side="left" className="w-full gap-0 p-0 sm:max-w-md">
        <SheetHeader className="border-b border-border p-6 text-start">
          <SheetTitle className="font-display text-2xl uppercase tracking-wide">
            CART <span className="font-sans text-base font-normal text-muted-foreground">({count} قطعة)</span>
          </SheetTitle>
          <SheetDescription>راجع المقاسات والكميات قبل تأكيد الطلب.</SheetDescription>
        </SheetHeader>

        {lines.length === 0 ? (
          <Empty className="flex-1">
            <EmptyHeader>
              <EmptyMedia variant="icon">
                <ShoppingBag />
              </EmptyMedia>
              <EmptyTitle>السلة فاضية</EmptyTitle>
              <EmptyDescription>ابدأ بإضافة قطعتك المفضلة من المتجر.</EmptyDescription>
            </EmptyHeader>
            <Button render={<Link href="/#shop" />} nativeButton={false} onClick={() => setOpen(false)}>
              تسوق الآن
            </Button>
          </Empty>
        ) : (
          <>
            <ul className="flex flex-1 flex-col gap-5 overflow-y-auto p-6">
              {lines.map((line) => (
                <li key={`${line.slug}-${line.size}`} className="flex gap-4 animate-in fade-in slide-in-from-left-4 duration-300">
                  <Link
                    href={`/product/${line.slug}`}
                    onClick={() => setOpen(false)}
                    className="relative size-24 shrink-0 overflow-hidden rounded-lg bg-studio"
                  >
                    <Image src={line.product.image} alt={line.product.name} fill sizes="96px" className="object-cover" />
                  </Link>
                  <div className="flex min-w-0 flex-1 flex-col gap-2">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <p className="truncate font-medium">{line.product.name}</p>
                        <p className="text-xs text-muted-foreground">{formatEGP(line.product.price)} للقطعة</p>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon-sm"
                        onClick={() => remove(line.slug, line.size)}
                        aria-label={`حذف ${line.product.name}`}
                      >
                        <Trash2 />
                      </Button>
                    </div>
                    <div className="flex items-center justify-between gap-2">
                      <label className="flex items-center gap-2 text-xs text-muted-foreground">
                        المقاس
                        <select
                          value={line.size}
                          onChange={(e) => setSize(line.slug, line.size, e.target.value)}
                          className="rounded-md border border-input bg-background px-2 py-1 text-sm text-foreground"
                        >
                          {getSizes(line.product.category).map((s) => (
                            <option key={s} value={s}>
                              {s}
                            </option>
                          ))}
                        </select>
                      </label>
                      <div className="flex items-center rounded-full border border-border" role="group" aria-label="الكمية">
                        <Button
                          variant="ghost"
                          size="icon-sm"
                          className="rounded-full"
                          onClick={() => (line.qty === 1 ? remove(line.slug, line.size) : setQty(line.slug, line.size, line.qty - 1))}
                          aria-label="تقليل الكمية"
                        >
                          <Minus />
                        </Button>
                        <span className="w-6 text-center text-sm tabular-nums" aria-live="polite">
                          {line.qty}
                        </span>
                        <Button
                          variant="ghost"
                          size="icon-sm"
                          className="rounded-full"
                          disabled={line.qty >= MAX_QTY_PER_LINE}
                          onClick={() => setQty(line.slug, line.size, line.qty + 1)}
                          aria-label="زيادة الكمية"
                        >
                          <Plus />
                        </Button>
                      </div>
                    </div>
                    <p className="text-sm font-semibold tabular-nums">{formatEGP(line.product.price * line.qty)}</p>
                  </div>
                </li>
              ))}
            </ul>

            <SheetFooter className="gap-4 border-t border-border p-6">
              {remaining > 0 ? (
                <div className="flex flex-col gap-2">
                  <p className="text-xs text-muted-foreground">
                    {"باقي "}
                    <span className="font-semibold text-foreground">{formatEGP(remaining)}</span>
                    {" على الشحن المجاني"}
                  </p>
                  <div className="h-1 overflow-hidden rounded-full bg-muted">
                    <div
                      className="h-full rounded-full bg-primary transition-[width] duration-500"
                      style={{ width: `${Math.min(100, (subtotal / FREE_SHIPPING_THRESHOLD) * 100)}%` }}
                    />
                  </div>
                </div>
              ) : (
                <p className="text-xs text-primary">مبروك! طلبك مؤهل للشحن المجاني</p>
              )}
              <dl className="flex flex-col gap-2 text-sm">
                <div className="flex justify-between">
                  <dt className="text-muted-foreground">المجموع الفرعي</dt>
                  <dd className="tabular-nums">{formatEGP(subtotal)}</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-muted-foreground">الشحن</dt>
                  <dd className="tabular-nums">{shipping === 0 ? "مجاني" : formatEGP(shipping)}</dd>
                </div>
                <Separator className="my-1" />
                <div className="flex justify-between text-base font-semibold">
                  <dt>الإجمالي</dt>
                  <dd className="tabular-nums">{formatEGP(total)}</dd>
                </div>
              </dl>
              <Button size="lg" className="h-12 w-full text-base" onClick={handleCheckout} disabled={checkingOut}>
                {checkingOut ? "جاري التحقق..." : "إتمام الطلب"}
              </Button>
            </SheetFooter>
          </>
        )}
      </SheetContent>
    </Sheet>
  )
}
