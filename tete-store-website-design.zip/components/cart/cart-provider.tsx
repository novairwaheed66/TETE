"use client"

import { createContext, useCallback, useContext, useMemo, useReducer, useState } from "react"
import { getProduct, type Product } from "@/lib/products"

export const MAX_QTY_PER_LINE = 10

export type CartLine = { slug: string; size: string; qty: number }

type Action =
  | { type: "add"; slug: string; size: string; qty: number }
  | { type: "setQty"; slug: string; size: string; qty: number }
  | { type: "setSize"; slug: string; size: string; nextSize: string }
  | { type: "remove"; slug: string; size: string }
  | { type: "clear" }

const sameLine = (l: CartLine, slug: string, size: string) => l.slug === slug && l.size === size
const clampQty = (qty: number) => Math.max(1, Math.min(MAX_QTY_PER_LINE, Math.floor(qty)))

function reducer(state: CartLine[], action: Action): CartLine[] {
  switch (action.type) {
    case "add": {
      const existing = state.find((l) => sameLine(l, action.slug, action.size))
      if (existing) {
        return state.map((l) =>
          sameLine(l, action.slug, action.size) ? { ...l, qty: clampQty(l.qty + action.qty) } : l,
        )
      }
      return [...state, { slug: action.slug, size: action.size, qty: clampQty(action.qty) }]
    }
    case "setQty":
      return state.map((l) => (sameLine(l, action.slug, action.size) ? { ...l, qty: clampQty(action.qty) } : l))
    case "setSize": {
      const moving = state.find((l) => sameLine(l, action.slug, action.size))
      if (!moving || action.size === action.nextSize) return state
      const rest = state.filter((l) => !sameLine(l, action.slug, action.size))
      const target = rest.find((l) => sameLine(l, action.slug, action.nextSize))
      if (target) {
        return rest.map((l) => (l === target ? { ...l, qty: clampQty(l.qty + moving.qty) } : l))
      }
      return [...rest, { ...moving, size: action.nextSize }]
    }
    case "remove":
      return state.filter((l) => !sameLine(l, action.slug, action.size))
    case "clear":
      return []
  }
}

type CartContextValue = {
  lines: (CartLine & { product: Product })[]
  count: number
  subtotal: number
  isOpen: boolean
  bumpKey: number
  setOpen: (open: boolean) => void
  add: (slug: string, size: string, qty?: number, sourceEl?: HTMLElement | null) => void
  setQty: (slug: string, size: string, qty: number) => void
  setSize: (slug: string, size: string, nextSize: string) => void
  remove: (slug: string, size: string) => void
  clear: () => void
}

const CartContext = createContext<CartContextValue | null>(null)

function flyToCart(imageSrc: string, sourceEl: HTMLElement, onArrive: () => void) {
  const target = document.getElementById("cart-button")
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches
  if (!target || reduceMotion) {
    onArrive()
    return
  }
  const from = sourceEl.getBoundingClientRect()
  const to = target.getBoundingClientRect()
  const size = Math.min(140, Math.max(72, from.width * 0.5))
  const startX = from.left + from.width / 2 - size / 2
  const startY = from.top + from.height / 2 - size / 2
  const dx = to.left + to.width / 2 - size / 2 - startX
  const dy = to.top + to.height / 2 - size / 2 - startY

  const ghost = document.createElement("img")
  ghost.src = imageSrc
  ghost.alt = ""
  ghost.setAttribute("aria-hidden", "true")
  Object.assign(ghost.style, {
    position: "fixed",
    left: `${startX}px`,
    top: `${startY}px`,
    width: `${size}px`,
    height: `${size}px`,
    objectFit: "cover",
    borderRadius: "16px",
    zIndex: "100",
    pointerEvents: "none",
    boxShadow: "0 20px 60px -10px oklch(0.72 0.19 45 / 0.55)",
    outline: "1px solid oklch(1 0 0 / 0.15)",
  })
  document.body.appendChild(ghost)

  const animation = ghost.animate(
    [
      { transform: "translate(0, 0) scale(1) rotate(0deg)", opacity: 1 },
      { transform: `translate(${dx * 0.45}px, ${dy * 0.45 - 120}px) scale(0.75) rotate(-8deg)`, opacity: 1, offset: 0.45 },
      { transform: `translate(${dx}px, ${dy}px) scale(0.12) rotate(12deg)`, opacity: 0.4 },
    ],
    { duration: 850, easing: "cubic-bezier(0.55, 0, 0.3, 1)" },
  )
  animation.onfinish = () => {
    ghost.remove()
    onArrive()
  }
}

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(reducer, [])
  const [isOpen, setOpen] = useState(false)
  const [bumpKey, setBumpKey] = useState(0)

  const add = useCallback<CartContextValue["add"]>((slug, size, qty = 1, sourceEl) => {
    const product = getProduct(slug)
    if (!product) return
    const commit = () => {
      dispatch({ type: "add", slug, size, qty })
      setBumpKey((k) => k + 1)
    }
    if (sourceEl) flyToCart(product.image, sourceEl, commit)
    else commit()
  }, [])

  const value = useMemo<CartContextValue>(() => {
    const lines = state.flatMap((l) => {
      const product = getProduct(l.slug)
      return product ? [{ ...l, product }] : []
    })
    return {
      lines,
      count: lines.reduce((sum, l) => sum + l.qty, 0),
      subtotal: lines.reduce((sum, l) => sum + l.qty * l.product.price, 0),
      isOpen,
      bumpKey,
      setOpen,
      add,
      setQty: (slug, size, qty) => dispatch({ type: "setQty", slug, size, qty }),
      setSize: (slug, size, nextSize) => dispatch({ type: "setSize", slug, size, nextSize }),
      remove: (slug, size) => dispatch({ type: "remove", slug, size }),
      clear: () => dispatch({ type: "clear" }),
    }
  }, [state, isOpen, bumpKey, add])

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>
}

export function useCart() {
  const ctx = useContext(CartContext)
  if (!ctx) throw new Error("useCart must be used within CartProvider")
  return ctx
}
