import Link from "next/link"
import { ArrowDown } from "lucide-react"
import { Button } from "@/components/ui/button"
import { ProductCard } from "@/components/product-card"
import { getFeaturedProducts } from "@/lib/products"

export function Hero() {
  const featured = getFeaturedProducts()

  return (
    <section className="relative overflow-hidden" aria-labelledby="hero-title">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-x-0 top-0 h-[70vh] bg-[radial-gradient(60%_50%_at_50%_0%,oklch(0.72_0.19_45/0.14),transparent)]"
      />
      <div className="relative mx-auto flex max-w-7xl flex-col gap-10 px-4 pt-14 pb-20 md:px-8 md:pt-20">
        <div className="flex flex-col items-center gap-6 text-center animate-in fade-in slide-in-from-bottom-6 duration-1000">
          <p className="rounded-full border border-border px-4 py-1.5 font-display text-xs tracking-[0.3em] text-muted-foreground uppercase">
            FW26 — NEW DROP
          </p>
          <h1
            id="hero-title"
            dir="ltr"
            className="font-display text-[19vw] leading-[0.85] tracking-tight uppercase md:text-[11rem] lg:text-[13rem]"
          >
            TETE<span className="text-primary">.</span>STORE
          </h1>
          <p className="max-w-xl text-pretty text-lg leading-relaxed text-muted-foreground">
            Streetwear مصري بخامات قطن ثقيلة وتفاصيل مصنوعة بعناية. قطع تعيش معاك، مش موسم وخلاص.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-3">
            <Button size="lg" className="h-12 px-8 text-base" render={<Link href="#shop" />} nativeButton={false}>
              تسوق المجموعة
            </Button>
            <Button size="lg" variant="outline" className="h-12 px-8 text-base" render={<Link href="#story" />} nativeButton={false}>
              اكتشف قصة القطعة
              <ArrowDown data-icon="inline-end" />
            </Button>
          </div>
        </div>

        <div id="featured" className="scroll-mt-24">
          <div className="mb-5 flex items-end justify-between">
            <h2 className="font-display text-2xl tracking-wide uppercase">
              FEATURED JACKETS <span className="font-sans text-base font-normal text-muted-foreground">— الأكثر طلباً</span>
            </h2>
          </div>
          <ul className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {featured.map((product, i) => (
              <li
                key={product.slug}
                className="animate-in fade-in slide-in-from-bottom-8 fill-mode-both duration-700"
                style={{ animationDelay: `${200 + i * 120}ms` }}
              >
                <ProductCard product={product} priority size="large" />
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  )
}
