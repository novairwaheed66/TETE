import Link from "next/link"

export function SiteFooter() {
  return (
    <footer className="border-t border-border">
      <div className="mx-auto flex max-w-7xl flex-col gap-10 px-4 py-14 md:px-8">
        <p className="font-display text-[18vw] leading-none uppercase tracking-tight text-foreground/[0.06] md:text-[12rem]" aria-hidden="true">
          TETE STORE
        </p>
        <div className="flex flex-col justify-between gap-6 text-sm text-muted-foreground md:flex-row md:items-center">
          <p>{"© 2026 TETE STORE — مصنوع في مصر بخامات فاخرة."}</p>
          <ul className="flex flex-wrap gap-6">
            <li>
              <Link href="/#shop" className="hover:text-foreground">المتجر</Link>
            </li>
            <li>
              <Link href="/#story" className="hover:text-foreground">قصة القطعة</Link>
            </li>
            <li>
              <span>شحن لكل المحافظات</span>
            </li>
            <li>
              <span>استبدال خلال 14 يوم</span>
            </li>
          </ul>
        </div>
      </div>
    </footer>
  )
}
