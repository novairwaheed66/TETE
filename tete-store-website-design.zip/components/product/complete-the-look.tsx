"use client"

import Image from "next/image"
import Link from "next/link"
import { useRef } from "react"
import { Plus, Sparkles } from "lucide-react"
import { toast } from "sonner"
import { Button } from "@/components/ui/button"
import { SpotlightCard } from "@/components/spotlight-card"
import { useCart } from "@/components/cart/cart-provider"
import { formatEGP, getDefaultSize, type Product } from "@/lib/products"

const BUNDLE_LABEL = "تنسيق الطقم"

export function CompleteTheLook({ product, items }: { product: Product; items: Product[] }) {
  const { add } = useCart()
  const refs = useRef<(HTMLDivElement | null)[]>([])
  const look = [product, ...items]
  const total = look.reduce((sum, p) => sum + p.price, 0)

  function addLook() {
    look.forEach((p, i) => {
      window.setTimeout(() => add(p.slug, getDefaultSize(p.category), 1, refs.current[i]), i * 160)
    })
    toast.success("أُضيف الطقم كامل للسلة", { description: "بالمقاسات الافتراضية (M / 32) — تقدر تعدّلها من السلة" })
  }

  return (
    <section aria-labelledby="look-title" className="flex flex-col gap-8">
      <div className="flex flex-col justify-between gap-4 md:flex-row md:items-end">
        <div className="flex flex-col gap-2">
          <p className="font-display text-sm tracking-[0.3em] text-primary uppercase">COMPLETE THE LOOK</p>
          <h2 id="look-title" className="text-3xl font-bold md:text-4xl">
            {BUNDLE_LABEL}
          </h2>
          <p className="text-muted-foreground">قطع اخترناها لتكمّل {product.name} في لوك واحد متناسق.</p>
        </div>
        <div className="flex items-center gap-4">
          <p className="text-sm text-muted-foreground">
            إجمالي الطقم <span className="block text-xl font-semibold text-foreground tabular-nums">{formatEGP(total)}</span>
          </p>
          <Button size="lg" className="h-12 rounded-full px-6" onClick={addLook}>
            <Sparkles data-icon="inline-start" />
            أضف الطقم كامل
          </Button>
        </div>
      </div>

      <ul className="grid items-center gap-4 sm:grid-cols-[1fr_auto_1fr_auto_1fr]">
        {look.map((p, i) => (
          <li key={p.slug} className="contents">
            {i > 0 && (
              <span className="hidden size-10 items-center justify-center justify-self-center rounded-full border border-border text-muted-foreground sm:flex" aria-hidden="true">
                <Plus className="size-4" />
              </span>
            )}
            <SpotlightCard className="rounded-2xl border border-border bg-studio">
              <Link href={`/product/${p.slug}`} className="group block">
                <div ref={(el) => { refs.current[i] = el }} className="relative aspect-square">
                  <Image src={p.image} alt={p.name} fill sizes="(min-width: 640px) 30vw, 100vw" className="object-cover transition-transform duration-700 group-hover:scale-105" />
                  {i === 0 && (
                    <span className="absolute top-3 start-3 rounded-full bg-primary px-3 py-1 text-xs font-semibold text-primary-foreground">
                      القطعة الحالية
                    </span>
                  )}
                </div>
                <div className="flex items-center justify-between gap-2 p-4">
                  <span className="truncate font-medium">{p.name}</span>
                  <span className="shrink-0 text-sm tabular-nums text-muted-foreground">{formatEGP(p.price)}</span>
                </div>
              </Link>
            </SpotlightCard>
          </li>
        ))}
      </ul>
    </section>
  )
}
