"use client"

import Image from "next/image"
import { useRef, useState } from "react"
import { Minus, Plus, RotateCcw, ShoppingBag, Truck } from "lucide-react"
import { toast } from "sonner"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group"
import { SpotlightCard } from "@/components/spotlight-card"
import { SizeGuideDialog } from "@/components/product/size-guide-dialog"
import { MAX_QTY_PER_LINE, useCart } from "@/components/cart/cart-provider"
import { formatEGP, getCategoryLabel, getSizes, type Product } from "@/lib/products"

export function ProductDetail({ product }: { product: Product }) {
  const { add } = useCart()
  const [size, setSize] = useState<string | null>(null)
  const [qty, setQty] = useState(1)
  const [sizeError, setSizeError] = useState(false)
  const imageRef = useRef<HTMLDivElement>(null)

  function handleAdd() {
    if (!size) {
      setSizeError(true)
      return
    }
    add(product.slug, size, qty, imageRef.current)
    toast.success(`أُضيف ${product.name} للسلة`, { description: `المقاس ${size} × ${qty}` })
  }

  return (
    <div className="grid gap-10 lg:grid-cols-2 lg:gap-16">
      <div className="animate-in fade-in zoom-in-95 duration-700">
        <SpotlightCard className="rounded-3xl border border-border bg-studio" intensity={0.1}>
          <div ref={imageRef} className="relative aspect-square">
            <Image
              src={product.image}
              alt={product.name}
              fill
              priority
              sizes="(min-width: 1024px) 50vw, 100vw"
              className="object-cover"
            />
          </div>
        </SpotlightCard>
      </div>

      <div className="flex flex-col gap-6 animate-in fade-in slide-in-from-bottom-6 fill-mode-both duration-700 delay-150">
        <div className="flex flex-col gap-3">
          <div className="flex items-center gap-2">
            <Badge variant="secondary">{getCategoryLabel(product.category)}</Badge>
            <span className="font-display text-xs tracking-[0.25em] text-muted-foreground uppercase">{product.nameEn}</span>
          </div>
          <h1 className="text-balance text-4xl leading-tight font-bold md:text-5xl">{product.name}</h1>
          <p className="text-2xl font-semibold tabular-nums text-primary">{formatEGP(product.price)}</p>
          <p className="text-pretty leading-relaxed text-muted-foreground">{product.description}</p>
        </div>

        <dl className="grid grid-cols-2 gap-4 rounded-2xl border border-border p-4 text-sm">
          <div className="flex flex-col gap-1">
            <dt className="text-muted-foreground">اللون</dt>
            <dd>{product.color}</dd>
          </div>
          <div className="flex flex-col gap-1">
            <dt className="text-muted-foreground">الخامة</dt>
            <dd>{product.fabric}</dd>
          </div>
        </dl>

        <div className="flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <p id="size-label" className="font-medium">
              اختر المقاس {size && <span className="text-muted-foreground">— {size}</span>}
            </p>
            <SizeGuideDialog category={product.category} />
          </div>
          <ToggleGroup
            aria-labelledby="size-label"
            value={size ? [size] : []}
            onValueChange={(v) => {
              setSize(v[0] ?? null)
              setSizeError(false)
            }}
            variant="outline"
            spacing={2}
            className="flex-wrap"
          >
            {getSizes(product.category).map((s) => (
              <ToggleGroupItem
                key={s}
                value={s}
                className="h-11 min-w-14 data-[pressed]:border-primary data-[pressed]:bg-primary data-[pressed]:text-primary-foreground"
              >
                {s}
              </ToggleGroupItem>
            ))}
          </ToggleGroup>
          {sizeError && (
            <p role="alert" className="text-sm text-destructive animate-in fade-in slide-in-from-top-1">
              من فضلك اختر المقاس الأول
            </p>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="flex h-12 items-center rounded-full border border-border" role="group" aria-label="الكمية">
            <Button variant="ghost" size="icon" className="rounded-full" onClick={() => setQty((q) => Math.max(1, q - 1))} disabled={qty <= 1} aria-label="تقليل الكمية">
              <Minus />
            </Button>
            <span className="w-8 text-center tabular-nums" aria-live="polite">{qty}</span>
            <Button variant="ghost" size="icon" className="rounded-full" onClick={() => setQty((q) => Math.min(MAX_QTY_PER_LINE, q + 1))} disabled={qty >= MAX_QTY_PER_LINE} aria-label="زيادة الكمية">
              <Plus />
            </Button>
          </div>
          <Button size="lg" className="h-12 flex-1 rounded-full text-base transition-transform active:scale-[0.98]" onClick={handleAdd}>
            <ShoppingBag data-icon="inline-start" />
            أضف للسلة — {formatEGP(product.price * qty)}
          </Button>
        </div>

        <Separator />

        <ul className="flex flex-col gap-3 text-sm text-muted-foreground">
          <li className="flex items-center gap-3">
            <Truck className="size-4 text-foreground" aria-hidden="true" />
            شحن لكل المحافظات خلال 2–4 أيام، ومجاني فوق 3,000 ج.م
          </li>
          <li className="flex items-center gap-3">
            <RotateCcw className="size-4 text-foreground" aria-hidden="true" />
            استبدال مجاني للمقاس خلال 14 يوم
          </li>
        </ul>
      </div>
    </div>
  )
}
