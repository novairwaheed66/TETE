"use client"

import { Ruler } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import type { Category } from "@/lib/products"

const TOPS = [
  { size: "S", chest: "112", length: "68", shoulder: "54", fit: "55 – 65" },
  { size: "M", chest: "118", length: "70", shoulder: "56", fit: "65 – 75" },
  { size: "L", chest: "124", length: "72", shoulder: "58", fit: "75 – 85" },
  { size: "XL", chest: "130", length: "74", shoulder: "60", fit: "85 – 95" },
  { size: "XXL", chest: "136", length: "76", shoulder: "62", fit: "95 – 110" },
]

const PANTS = [
  { size: "30", waist: "76", hip: "104", length: "102", fit: "60 – 68" },
  { size: "32", waist: "81", hip: "108", length: "104", fit: "68 – 76" },
  { size: "34", waist: "86", hip: "112", length: "106", fit: "76 – 85" },
  { size: "36", waist: "91", hip: "116", length: "107", fit: "85 – 95" },
  { size: "38", waist: "96", hip: "120", length: "108", fit: "95 – 108" },
]

export function SizeGuideDialog({ category }: { category: Category }) {
  const isPants = category === "pants"

  return (
    <Dialog>
      <DialogTrigger render={<Button variant="link" className="h-auto px-0 text-muted-foreground" />}>
        <Ruler data-icon="inline-start" />
        دليل المقاسات (Size Guide)
      </DialogTrigger>
      <DialogContent className="sm:max-w-xl" dir="rtl">
        <DialogHeader className="text-start">
          <DialogTitle className="font-display text-2xl tracking-wide uppercase">SIZE GUIDE</DialogTitle>
          <DialogDescription>
            {isPants
              ? "المقاسات بالسنتيمتر. القصّة واسعة (Baggy)، لو بتحب الفيت المظبوط اختار مقاسك المعتاد."
              : "المقاسات بالسنتيمتر للقطعة نفسها. القصّة أوفرسايز، لو بتحب الفيت العادي انزل مقاس."}
          </DialogDescription>
        </DialogHeader>
        <div className="overflow-x-auto rounded-lg border border-border">
          <Table>
            <TableHeader>
              {isPants ? (
                <TableRow>
                  <TableHead className="text-start">المقاس</TableHead>
                  <TableHead className="text-start">الوسط</TableHead>
                  <TableHead className="text-start">الأرداف</TableHead>
                  <TableHead className="text-start">الطول</TableHead>
                  <TableHead className="text-start">الوزن (كجم)</TableHead>
                </TableRow>
              ) : (
                <TableRow>
                  <TableHead className="text-start">المقاس</TableHead>
                  <TableHead className="text-start">الصدر</TableHead>
                  <TableHead className="text-start">الطول</TableHead>
                  <TableHead className="text-start">الأكتاف</TableHead>
                  <TableHead className="text-start">الوزن (كجم)</TableHead>
                </TableRow>
              )}
            </TableHeader>
            <TableBody>
              {isPants
                ? PANTS.map((r) => (
                    <TableRow key={r.size}>
                      <TableCell className="font-semibold">{r.size}</TableCell>
                      <TableCell>{r.waist}</TableCell>
                      <TableCell>{r.hip}</TableCell>
                      <TableCell>{r.length}</TableCell>
                      <TableCell dir="ltr" className="text-end">{r.fit}</TableCell>
                    </TableRow>
                  ))
                : TOPS.map((r) => (
                    <TableRow key={r.size}>
                      <TableCell className="font-semibold">{r.size}</TableCell>
                      <TableCell>{r.chest}</TableCell>
                      <TableCell>{r.length}</TableCell>
                      <TableCell>{r.shoulder}</TableCell>
                      <TableCell dir="ltr" className="text-end">{r.fit}</TableCell>
                    </TableRow>
                  ))}
            </TableBody>
          </Table>
        </div>
        <p className="text-xs text-muted-foreground">
          نصيحة: قيس قطعة عندك بتحبها وقارنها بالجدول — دي أدق طريقة لاختيار المقاس.
        </p>
      </DialogContent>
    </Dialog>
  )
}
