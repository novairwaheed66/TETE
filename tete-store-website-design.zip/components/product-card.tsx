"use client"

import Image from "next/image"
import Link from "next/link"
import { useRef } from "react"
import { Plus } from "lucide-react"
import { toast } from "sonner"
import { SpotlightCard } from "@/components/spotlight-card"
import { useCart } from "@/components/cart/cart-provider"
import { formatEGP, getCategoryLabel, getDefaultSize, type Product } from "@/lib/products"
import { cn } from "@/lib/utils"

export function ProductCard({
  product,
  priority,
  size = "default",
}: {
  product: Product
  priority?: boolean
  size?: "default" | "large"
}) {
  const { add } = useCart()
  const imageRef = useRef<HTMLDivElement>(null)

  function handleQuickAdd() {
    const defaultSize = getDefaultSize(product.category)
    add(product.slug, defaultSize, 1, imageRef.current)
    toast.success(`أُضيف ${product.name} للسلة`, { description: `المقاس ${defaultSize} — تقدر تغيّره من السلة` })
  }

  return (
    <SpotlightCard className="rounded-2xl border border-border bg-studio">
      <article className="flex h-full flex-col">
        <Link href={`/product/${product.slug}`} className="group/link block focus-visible:outline-none">
          <div ref={imageRef} className={cn("relative overflow-hidden", size === "large" ? "aspect-[4/5]" : "aspect-square")}>
            <Image
              src={product.image}
              alt={product.name}
              fill
              priority={priority}
              sizes={size === "large" ? "(min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw" : "(min-width: 1024px) 25vw, (min-width: 640px) 50vw, 100vw"}
              className="object-cover transition-transform duration-700 ease-out group-hover/link:scale-105"
            />
            <span className="absolute top-3 start-3 rounded-full bg-background/70 px-3 py-1 font-display text-[11px] tracking-widest uppercase backdrop-blur">
              {product.nameEn}
            </span>
          </div>
          <span className="sr-only">عرض تفاصيل {product.name}</span>
        </Link>
        <div className="flex flex-1 items-end justify-between gap-3 p-4">
          <div className="min-w-0">
            <p className="text-xs text-muted-foreground">{getCategoryLabel(product.category)}</p>
            <h3 className="truncate font-semibold">
              <Link href={`/product/${product.slug}`} className="hover:text-primary">
                {product.name}
              </Link>
            </h3>
            <p className="mt-1 text-sm tabular-nums">{formatEGP(product.price)}</p>
          </div>
          <button
            type="button"
            onClick={handleQuickAdd}
            className="relative z-20 flex size-11 shrink-0 items-center justify-center rounded-full bg-foreground text-background transition-all hover:scale-110 hover:bg-primary active:scale-95 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
            aria-label={`إضافة ${product.name} للسلة`}
          >
            <Plus className="size-5" aria-hidden="true" />
          </button>
        </div>
      </article>
    </SpotlightCard>
  )
}
