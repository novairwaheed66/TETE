import { Hero } from "@/components/hero"
import { ScrollStory } from "@/components/scroll-story/scroll-story"
import { ShopSection } from "@/components/shop-section"

export default function HomePage() {
  return (
    <main>
      <Hero />
      <ScrollStory />
      <ShopSection />
    </main>
  )
}
