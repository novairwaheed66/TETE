import type { Metadata } from "next"
import Link from "next/link"
import { notFound } from "next/navigation"
import { ArrowRight } from "lucide-react"
import { ProductDetail } from "@/components/product/product-detail"
import { CompleteTheLook } from "@/components/product/complete-the-look"
import { PRODUCTS, getCompleteTheLook, getProduct } from "@/lib/products"

export const dynamicParams = false

export function generateStaticParams() {
  return PRODUCTS.map((p) => ({ slug: p.slug }))
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params
  const product = getProduct(slug)
  if (!product) return {}
  return {
    title: `${product.name} — TETE STORE`,
    description: product.description,
    openGraph: { images: [product.image] },
  }
}

export default async function ProductPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  const product = getProduct(slug)
  if (!product) notFound()

  return (
    <main className="mx-auto flex max-w-7xl flex-col gap-20 px-4 pt-8 pb-24 md:px-8">
      <div className="flex flex-col gap-8">
        <Link
          href="/#shop"
          className="group inline-flex w-fit items-center gap-2 rounded-full border border-border px-4 py-2 text-sm transition-colors hover:border-primary/60 hover:text-primary animate-in fade-in slide-in-from-right-4 duration-500"
        >
          <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" aria-hidden="true" />
          العودة للمتجر
        </Link>
        <ProductDetail product={product} />
      </div>
      <CompleteTheLook product={product} items={getCompleteTheLook(product)} />
    </main>
  )
}
