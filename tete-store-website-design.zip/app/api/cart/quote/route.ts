import { getProduct, getSizes } from "@/lib/products"

const MAX_LINES = 30
const MAX_QTY_PER_PRODUCT = 10

type IncomingLine = { slug?: unknown; size?: unknown; qty?: unknown }

export async function POST(request: Request) {
  let body: { lines?: IncomingLine[] }
  try {
    body = await request.json()
  } catch {
    return Response.json({ error: "طلب غير صالح" }, { status: 400 })
  }

  const lines = Array.isArray(body.lines) ? body.lines : null
  if (!lines || lines.length === 0 || lines.length > MAX_LINES) {
    return Response.json({ error: "السلة فارغة أو تحتوي على عناصر كثيرة" }, { status: 400 })
  }

  const qtyPerProduct = new Map<string, number>()
  const items = []

  for (const line of lines) {
    if (typeof line.slug !== "string" || typeof line.size !== "string" || typeof line.qty !== "number") {
      return Response.json({ error: "بيانات عنصر غير صالحة" }, { status: 400 })
    }
    const product = getProduct(line.slug)
    if (!product || !getSizes(product.category).includes(line.size)) {
      return Response.json({ error: "منتج أو مقاس غير متاح" }, { status: 422 })
    }
    if (!Number.isInteger(line.qty) || line.qty < 1) {
      return Response.json({ error: "كمية غير صالحة" }, { status: 422 })
    }
    const total = (qtyPerProduct.get(product.slug) ?? 0) + line.qty
    if (total > MAX_QTY_PER_PRODUCT) {
      return Response.json({ error: `الحد الأقصى ${MAX_QTY_PER_PRODUCT} قطع من ${product.name}` }, { status: 422 })
    }
    qtyPerProduct.set(product.slug, total)
    items.push({ slug: product.slug, size: line.size, qty: line.qty, unitPrice: product.price, lineTotal: product.price * line.qty })
  }

  const subtotal = items.reduce((sum, i) => sum + i.lineTotal, 0)
  return Response.json(
    { items, subtotal, currency: "EGP" },
    { headers: { "Cache-Control": "no-store" } },
  )
}
