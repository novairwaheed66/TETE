import { PRODUCTS } from "@/lib/products"

export const dynamic = "force-static"
export const revalidate = 3600

export function GET() {
  return Response.json(
    { products: PRODUCTS },
    { headers: { "Cache-Control": "public, s-maxage=3600, stale-while-revalidate=86400" } },
  )
}
