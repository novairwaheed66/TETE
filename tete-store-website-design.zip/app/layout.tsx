import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { Anton, IBM_Plex_Sans_Arabic } from 'next/font/google'
import { Toaster } from '@/components/ui/sonner'
import { CartProvider } from '@/components/cart/cart-provider'
import { CartSheet } from '@/components/cart/cart-sheet'
import { SiteHeader } from '@/components/site-header'
import { SiteFooter } from '@/components/site-footer'
import './globals.css'

const anton = Anton({ subsets: ['latin'], weight: '400', variable: '--font-anton', display: 'swap' })
const plexArabic = IBM_Plex_Sans_Arabic({
  subsets: ['arabic', 'latin'],
  weight: ['400', '500', '600', '700'],
  variable: '--font-arabic',
  display: 'swap',
})

export const metadata: Metadata = {
  title: 'TETE STORE — Streetwear مصري بخامات فاخرة',
  description:
    'TETE STORE متجر Streetwear عصري: جواكت، هوديز، بناطيل وتيشرتات بخامات قطن فاخرة وأسعار بالجنيه المصري.',
  generator: 'v0.app',
  icons: {
    icon: [
      { url: '/icon-light-32x32.png', media: '(prefers-color-scheme: light)' },
      { url: '/icon-dark-32x32.png', media: '(prefers-color-scheme: dark)' },
      { url: '/icon.svg', type: 'image/svg+xml' },
    ],
    apple: '/apple-icon.png',
  },
}

export const viewport: Viewport = {
  colorScheme: 'dark',
  themeColor: '#161616',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="ar" dir="rtl" className={`${anton.variable} ${plexArabic.variable}`}>
      <body className="antialiased">
        <CartProvider>
          <SiteHeader />
          {children}
          <SiteFooter />
          <CartSheet />
        </CartProvider>
        <Toaster theme="dark" position="top-center" dir="rtl" richColors={false} />
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
